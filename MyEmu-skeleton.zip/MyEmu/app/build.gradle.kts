plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.myemu.ps4"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.myemu.ps4"
        minSdk = 31
        targetSdk = 35
        versionCode = 1
        versionName = "0.0.1"

        // Ядро и среда выполнения собираются только под ARM64
        ndk { abiFilters += "arm64-v8a" }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    buildFeatures { compose = true }

    // Нужно, чтобы .so-файлы (loader, box64/FEX и т.д.) распаковывались на диск.
    // Android не даёт запускать бинарники из приватной папки приложения,
    // поэтому их кладут в jniLibs как lib*.so и запускают из nativeLibraryDir.
    packaging {
        jniLibs { useLegacyPackaging = true }
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.documentfile:documentfile:1.0.1")

    implementation(platform("androidx.compose:compose-bom:2024.10.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
}
