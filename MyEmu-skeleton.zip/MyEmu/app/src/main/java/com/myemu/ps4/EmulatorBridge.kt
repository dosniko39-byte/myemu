package com.myemu.ps4

import android.content.Context
import android.net.Uri

/**
 * Точка подключения ядра эмулятора.
 *
 * Сейчас это заглушка. Сюда позже добавим:
 *  1. подготовку среды (распаковка Linux-окружения при первом запуске),
 *  2. запуск ядра shadps4-arm64 через загрузчик + FEX/Box64,
 *  3. передачу окна (Surface) для Vulkan и ввода (геймпад, сенсор).
 */
object EmulatorBridge {
    fun launch(context: Context, gameFolder: Uri, gameName: String): String {
        return "Ядро ещё не подключено. Выбрана игра: $gameName"
    }
}
