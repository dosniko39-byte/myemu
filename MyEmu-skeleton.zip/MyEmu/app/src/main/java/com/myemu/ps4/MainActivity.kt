package com.myemu.ps4

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ListItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile

data class Game(val name: String, val uri: Uri)

private const val PREFS = "myemu"
private const val KEY_GAMES_DIR = "games_dir"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) { GameListScreen() }
            }
        }
    }
}

/** Ищет внутри папки подпапки игр (в них должен лежать eboot.bin). */
fun scanGames(context: Context, treeUri: Uri): List<Game> {
    val root = DocumentFile.fromTreeUri(context, treeUri) ?: return emptyList()
    return root.listFiles()
        .filter { it.isDirectory && it.findFile("eboot.bin") != null }
        .map { Game(it.name ?: "?", it.uri) }
        .sortedBy { it.name }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameListScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
    var games by remember { mutableStateOf<List<Game>>(emptyList()) }

    LaunchedEffect(Unit) {
        prefs.getString(KEY_GAMES_DIR, null)?.let { games = scanGames(context, Uri.parse(it)) }
    }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            context.contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            prefs.edit().putString(KEY_GAMES_DIR, uri.toString()).apply()
            games = scanGames(context, uri)
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("MyEmu") }) }) { padding ->
        Column(Modifier.padding(padding).padding(16.dp)) {
            Button(onClick = { picker.launch(null) }) {
                Text("Выбрать папку с играми")
            }
            Spacer(Modifier.height(16.dp))
            if (games.isEmpty()) {
                Text(
                    "Игры не найдены. Выберите папку, внутри которой лежат папки игр " +
                        "(например, CUSA00001 с файлом eboot.bin)."
                )
            } else {
                LazyColumn {
                    items(games) { game ->
                        ListItem(
                            headlineContent = { Text(game.name) },
                            modifier = Modifier.clickable {
                                val msg = EmulatorBridge.launch(context, game.uri, game.name)
                                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                            }
                        )
                    }
                }
            }
        }
    }
}
